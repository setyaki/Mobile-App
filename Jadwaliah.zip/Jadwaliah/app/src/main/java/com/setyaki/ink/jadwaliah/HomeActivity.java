package com.setyaki.ink.jadwaliah;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

public class HomeActivity extends AppCompatActivity {
    private EditText edt1, edt2, edt3, edt4;
    private Button btnDet;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_notifications)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);

        if (savedInstanceState != null) {
            String hasil = savedInstanceState.getString(STATE_HASIL);
            tvResult.setText(hasil);
        }
    }



    public void klikTentang (View view){
        Intent myIntent = new Intent(getBaseContext(),   AboutActivity.class);
        startActivity(myIntent);
    }


    public void onClick(View v) {
        edt1 = (EditText)findViewById(R.id.edt_1);
        edt2 = (EditText)findViewById(R.id.edt_2);
        edt3 = (EditText)findViewById(R.id.edt_3);
        edt4 = (EditText)findViewById(R.id.edt_4);
        btnDet = (Button)findViewById(R.id.btn_det);
        tvResult = (TextView)findViewById(R.id.tv_result);

        if (v.getId() == R.id.btn_det){
            String edtA = edt1.getText().toString().trim();
            String edtB = edt2.getText().toString().trim();
            String edtC = edt3.getText().toString().trim();
            String edtD = edt4.getText().toString().trim();

            boolean isEmptyFields = false;
            if (TextUtils.isEmpty(edtA)){
                isEmptyFields = true;
                edt1.setError("Field ini tidak boleh kosong");
            }
            if (TextUtils.isEmpty(edtB)){
                isEmptyFields = true;
                edt2.setError("Field ini tidak boleh kosong");
            }
            if (TextUtils.isEmpty(edtC)){
                isEmptyFields = true;
                edt3.setError("Field ini tidak boleh kosong");
            }
            if (TextUtils.isEmpty(edtD)){
                isEmptyFields = true;
                edt4.setError("Field ini tidak boleh kosong");
            }
            if (!isEmptyFields) {
                float a = Float.parseFloat(edtA);
                float b = Float.parseFloat(edtB);
                float c = Float.parseFloat(edtC);
                float d = Float.parseFloat(edtD);
                float det = (a*d)-(c*b);
                tvResult.setText(String.valueOf(det));
            }
        }
    }

    private static final String STATE_HASIL = "state_hasil";
}
